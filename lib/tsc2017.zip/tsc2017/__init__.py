#------------------------------------------------------------------------------
#   TrajTracker external I/O interfaces: tsc2017 replacements
#------------------------------------------------------------------------------

from ._tsc2017 import Touchpad, TouchInfo, TSCError
from ._Mouse import Mouse
